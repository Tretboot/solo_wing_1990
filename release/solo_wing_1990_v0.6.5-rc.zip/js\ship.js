// ===== SOLO WING 1990 — WORLD STATE (Phase 6.3) =====
// Seed, aktuelles System, gesammelte Nachrufe, NPC-Placements.
// Das "fliegende Dorf" lebt: NPCs wandern je nach Seed/Mission,
// die Kapelle sammelt Nachrufe, das Observationsdeck zeigt das System.
SW.World = {
  seed: 1990,
  systemId: 's1',
  nachrufe: [],       // gesammelte Nachrufe (Kapelle)
  missionResult: null, // 'sieg' | 'tod' | null

  init(systemId, seed) {
    this.systemId = systemId || 's1';
    this.seed = seed || 1990;
    this.missionResult = null;
    // Nachrufe: aus gefallenen Piloten (Scoreboard) + generisch
    this.nachrufe = [];
    for (const p of SW.Scoreboard) {
      if (p.status === 'gefallen') {
        this.nachrufe.push({
          name: p.name,
          text: 'Gefallen im Dienst. ' + p.kills + ' Abschüsse. ' + this._nachrufText(p.name)
        });
      }
    }
    if (this.nachrufe.length === 0) {
      this.nachrufe.push({ name:'Vier', text:'Gefallen im Dienst. 0 Abschüsse. Hat gelacht, bis zum Schluss.' });
    }
  },

  _nachrufText(name) {
    const opts = [
      'Die Kantine hat eine Torte gebacken. Niemand hat sie gegessen.',
      'Kopfhörer sind noch in der Spinde. VHS-Karte nie bezahlt.',
      'Der Stuhl in der Bar ist jetzt frei. Jemand hat ihn umgedreht.',
      'Pfarrer Klopstock hat die Formel geändert. Einmal. Nur für ihn.'
    ];
    let h = 0;
    for (let i=0;i<name.length;i++) h=(h*31+name.charCodeAt(i))&0xffff;
    return opts[h % opts.length];
  },

  // Deterministischer Hash (für Seed-basierte Entscheidungen)
  _hash(str) {
    let h = this.seed;
    for (let i=0;i<str.length;i++) h = (h*31 + str.charCodeAt(i)) & 0xffff;
    return h;
  },

  // NPCs für einen Raum: Basis-NPCs + ggf. ein "gastierender" NPC (je nach Seed)
  npcInRoom(roomId) {
    const room = SW.Rooms.find(r => r.id === roomId);
    if (!room) return [];
    const base = room.npcs.slice();
    // Je nach Seed: ein Pilot "gastiert" in diesem Raum (deterministisch)
    const h = this._hash(roomId);
    const guests = ['Sechs','Neun','Zwo','Vier'];
    const guest = guests[h % guests.length];
    // Gast nur, wenn er nicht schon Basis-NPC ist und nicht gefallenen
    const guestData = SW.Scoreboard.find(p => p.name === guest);
    if (guestData && guestData.status !== 'gefallen' && base.indexOf(guest) < 0) {
      // Je nach Missionsergebnis: nach Sieg sitzt Sechs in der Bar, nach Tod Neun in der Kapelle
      if (this.missionResult === 'sieg' && roomId === 'bar' && guest !== 'Sechs') {
        base.push('Sechs');
      } else if (this.missionResult === 'tod' && roomId === 'kapelle' && guest !== 'Neun') {
        base.push('Neun');
      } else if (h % 3 === 0) {
        // In 1/3 der Räume gastiert ein Pilot
        base.push(guest);
      }
    }
    return base;
  },

  // System-Info (für Observationsdeck)
  systemInfo() {
    const sys = SW.Systems.find(s => s.id === this.systemId) || SW.Systems[0];
    return sys;
  }
};

// ===== SOLO WING 1990 — SHIP INTERIOR (Phase 6.1) =====
// Der Träger als "fliegendes Dorf". 10 statische Räume.
// Tür-Klick-Navigation, Minimap, prozeduraler Artstyle pro Raum, NPC-Dialoge.
// Konferenz: No Thinking + Lead Story Writer.

SW.Ship = {
  currentRoom: 'bar',
  dialogueActive: false,
  dialogueLines: [],
  dialogueIndex: 0,
  charIndex: 0,
  typing: true,
  talkingNPC: null,
  _frame: 0,
  _doorRects: [],
  _npcRects: [],

  init(systemId) {
    this.currentRoom = 'bar';
    this._frame = 0;
    this.dialogueActive = false;
    this.talkingNPC = null;
    // World-State initialisieren (Seed = Mission-Id + Zeit)
    const seed = (SW.Game.mission?.id || 'm1').charCodeAt(1) * 1000 + Math.floor(Date.now()/100000) % 1000;
    SW.World.init(systemId, seed);
  },

  getRoom() { return SW.Rooms.find(r => r.id === this.currentRoom) || SW.Rooms[0]; },

  // ===== NAVIGATION =====
  navigateTo(roomId) {
    const room = this.getRoom();
    if (room.toren.indexOf(roomId) < 0) return; // nur über Türen
    this.currentRoom = roomId;
    this.dialogueActive = false;
    this.talkingNPC = null;
    SW.Audio.playCommBeep();
  },

  // ===== DIALOG =====
  startDialogue() {
    const room = this.getRoom();
    const lines = SW.Dialogues.rooms[room.id] || [];
    if (lines.length === 0) return;
    this.dialogueLines = lines;
    this.dialogueIndex = 0;
    this.charIndex = 0;
    this.typing = true;
    this.dialogueActive = true;
    const line = lines[0];
    SW.TTS.speak(line.text, line.npc);
  },

  advanceDialogue() {
    if (!this.dialogueActive) { this.dialogueActive = false; return; }
    if (this.typing) {
      this.typing = false;
      this.charIndex = this.dialogueLines[this.dialogueIndex].text.length;
      return;
    }
    this.dialogueIndex++;
    if (this.dialogueIndex >= this.dialogueLines.length) {
      this.dialogueActive = false;
      this.talkingNPC = null;
      return;
    }
    this.charIndex = 0;
    this.typing = true;
    const line = this.dialogueLines[this.dialogueIndex];
    SW.TTS.speak(line.text, line.npc);
  },

  update() {
    this._frame++;
    if (!this.dialogueActive) return;
    if (this.typing) {
      this.charIndex++;
      if (this.charIndex >= this.dialogueLines[this.dialogueIndex].text.length) this.typing = false;
    }
  },

  // ===== KLIK-BEHANDLUNG =====
  handleClick(mx, my) {
    // Wandkarte (Minimap) geklickt → Fullscreen-Karte
    if (this._mapRect) {
      const m = this._mapRect;
      if (mx>=m.x && mx<=m.x+m.w && my>=m.y && my<=m.y+m.h) {
        SW.Game.state = 'CHEAT_MAP';
        return;
      }
    }
    // START-Button im Flugdeck
    if (this.currentRoom==='flugdeck' && this._startRect) {
      const s=this._startRect;
      if (mx>=s.x && mx<=s.x+s.w && my>=s.y && my<=s.y+s.h) {
        SW.Game.setState('BRIEFING_BOARD');
        return;
      }
    }
    // Tür geklickt?
    for (const d of this._doorRects) {
      if (mx >= d.x && mx <= d.x + d.w && my >= d.y && my <= d.y + d.h) {
        this.navigateTo(d.to);
        return;
      }
    }
    // NPC geklickt?
    for (const n of this._npcRects) {
      if (mx >= n.x && mx <= n.x + n.w && my >= n.y && my <= n.y + n.h) {
        this.talkingNPC = n.name;
        this.startDialogue();
        return;
      }
    }
    // Dialog fortsetzen
    if (this.dialogueActive) this.advanceDialogue();
  },

  // ===== RENDER =====
  render(ctx) {
    const room = this.getRoom();
    this._doorRects = [];
    this._npcRects = [];

    // Hintergrund
    ctx.fillStyle = room.farbe;
    ctx.fillRect(0, 0, SW.W, SW.H);

    // Raum-Art (prozedural, je Raum anders)
    this.renderArt(ctx, room);

    // Raum-Name + Zweck
    ctx.fillStyle = room.akzent;
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(room.name, SW.CX, 14);
    ctx.fillStyle = '#888';
    ctx.font = '6px monospace';
    ctx.fillText(room.zweck, SW.CX, 24);
    ctx.textAlign = 'left';

    // NPCs
    this.renderNPCs(ctx, room);

    // Türen
    this.renderDoors(ctx, room);

    // Minimap
    this.renderMap(ctx, room);

    // Dialog-Box
    if (this.dialogueActive) this.renderDialogue(ctx, room);
    else this.renderHint(ctx, room);
  },

  // ===== PROZEDURALER ARTSTYLE PRO RAUM =====
  renderArt(ctx, room) {
    switch (room.art) {
      case 'bar': this.artBar(ctx, room); break;
      case 'flugdeck': this.artFlugdeck(ctx, room); break;
      case 'buerro': this.artBuerro(ctx, room); break;
      case 'kantine': this.artKantine(ctx, room); break;
      case 'kapelle': this.artKapelle(ctx, room); break;
      case 'reparatur': this.artReparatur(ctx, room); break;
      case 'friseur': this.artFriseur(ctx, room); break;
      case 'beobachtung': this.artBeobachtung(ctx, room); break;
      case 'maschinenraum': this.artMaschinenraum(ctx, room); break;
      case 'krankenstation': this.artKrankenstation(ctx, room); break;
      case 'klo': this.artKlo(ctx, room); break;
    }
  },

  artBar(ctx, room) {
    // Fenster (polygonal, spacig)
    const win = { x:20, y:30, w:90, h:45, cut:10 };
    ctx.beginPath();
    ctx.moveTo(win.x+win.cut,win.y); ctx.lineTo(win.x+win.w-win.cut,win.y);
    ctx.lineTo(win.x+win.w,win.y+win.cut); ctx.lineTo(win.x+win.w,win.y+win.h-win.cut);
    ctx.lineTo(win.x+win.w-win.cut,win.y+win.h); ctx.lineTo(win.x+win.cut,win.y+win.h);
    ctx.lineTo(win.x,win.y+win.h-win.cut); ctx.lineTo(win.x,win.y+win.cut); ctx.closePath();
    ctx.fillStyle='#050510'; ctx.fill();
    ctx.strokeStyle=room.akzent; ctx.lineWidth=2; ctx.stroke();
    ctx.save(); ctx.clip();
    ctx.fillStyle='#fff';
    for(let i=0;i<18;i++) ctx.fillRect(win.x+3+(i*13)%84, win.y+3+(i*17)%39, 1,1);
    ctx.fillStyle=room.akzent; ctx.globalAlpha=0.15;
    ctx.beginPath(); ctx.arc(win.x+45,win.y+22,15,0,Math.PI*2); ctx.fill();
    ctx.globalAlpha=1; ctx.restore();
    // Theke
    ctx.fillStyle='#2a1e0e'; ctx.fillRect(0,SW.H-40,SW.W,40);
    ctx.fillStyle='#3a2a15'; ctx.fillRect(0,SW.H-40,SW.W,3);
    // Flaschen
    const bc=['#44aa44','#aa4444','#4444aa','#aaaa44','#aa44aa'];
    for(let i=0;i<8;i++){ const bx=25+i*35; ctx.fillStyle=bc[i%5]; ctx.globalAlpha=0.6;
      ctx.fillRect(bx,SW.H-50,4,10); ctx.fillRect(bx+1,SW.H-53,2,3); ctx.globalAlpha=1; }
    // Scoreboard
    ctx.fillStyle='#0a0a0a'; ctx.fillRect(130,30,110,60);
    ctx.strokeStyle=room.akzent; ctx.lineWidth=1; ctx.strokeRect(130,30,110,60);
    ctx.fillStyle=room.akzent; ctx.font='bold 7px monospace'; ctx.textAlign='center';
    ctx.fillText('P I L O T S', 185, 40); ctx.textAlign='left';
    for(let i=0;i<SW.Scoreboard.length;i++){ const p=SW.Scoreboard[i]; const py=48+i*9;
      ctx.fillStyle=p.farbe; ctx.fillRect(135,py-4,4,4);
      ctx.fillStyle=p.status==='gefallen'?'#555':'#ccc'; ctx.font='6px monospace';
      ctx.fillText(p.name,143,py); ctx.fillStyle='#888'; ctx.textAlign='right';
      ctx.fillText(p.kills+'/'+p.losses,235,py); ctx.textAlign='left'; }
  },

  artFlugdeck(ctx, room) {
    // Große Konsole
    ctx.fillStyle='#0a1520'; ctx.fillRect(20,40,280,100);
    ctx.strokeStyle=room.akzent; ctx.lineWidth=1; ctx.strokeRect(20,40,280,100);
    // Screens
    for(let i=0;i<3;i++){ const sx=30+i*90;
      ctx.fillStyle='#001a1a'; ctx.fillRect(sx,50,80,40);
      ctx.strokeStyle='#00ff00'; ctx.strokeRect(sx,50,80,40);
      ctx.fillStyle='#0f0'; ctx.font='5px monospace';
      ctx.fillText('SYSTEM OK', sx+5, 60);
      ctx.fillText('KURS: SEKTOR', sx+5, 70);
      ctx.fillText((7+i)+'  LOCK', sx+5, 80);
    }
    // Start-Button
    this._startRect={x:140,y:100,w:40,h:20};
    const blink=Math.floor(this._frame/30)%2===0;
    ctx.fillStyle=blink?'#0f0':'#030'; ctx.fillRect(140,100,40,20);
    ctx.fillStyle='#000'; ctx.font='bold 7px monospace'; ctx.textAlign='center';
    ctx.fillText('START', 160, 113); ctx.textAlign='left';
    // Boden
    ctx.fillStyle='#1a2530'; ctx.fillRect(0,SW.H-30,SW.W,30);
  },

  artBuerro(ctx, room) {
    // Schreibtisch
    ctx.fillStyle='#5a3a1a'; ctx.fillRect(40,110,240,30);
    ctx.fillStyle='#3a2a1a'; ctx.fillRect(40,140,240,10);
    // Aktenregale
    for(let i=0;i<4;i++){ ctx.fillStyle='#2a1a0a'; ctx.fillRect(20+i*70,40,60,60);
      ctx.strokeStyle='#5a3a1a'; ctx.strokeRect(20+i*70,40,60,60);
      for(let j=0;j<3;j++){ ctx.fillStyle='#4a3a2a'; ctx.fillRect(24+i*70,46+j*18,52,14); } }
    // Fax
    ctx.fillStyle='#888'; ctx.fillRect(150,95,40,15);
    ctx.fillStyle='#0f0'; ctx.fillRect(155,98,10,4);
    ctx.fillStyle='#000'; ctx.font='5px monospace'; ctx.fillText('FAX', 175, 105);
    // Boden
    ctx.fillStyle='#2a1a0a'; ctx.fillRect(0,SW.H-25,SW.W,25);
  },

  artKantine(ctx, room) {
    // Neon
    ctx.fillStyle='#0a0a0a'; ctx.fillRect(0,30,SW.W,20);
    ctx.fillStyle=room.akzent; ctx.font='bold 10px monospace'; ctx.textAlign='center';
    ctx.fillText('KANTINE "BROTZEIT 4711"', SW.CX, 44); ctx.textAlign='left';
    // Tische
    for(let i=0;i<3;i++){ const tx=40+i*90;
      ctx.fillStyle='#4a3a2a'; ctx.fillRect(tx,110,60,8);
      ctx.fillRect(tx+25,118,10,20);
      ctx.fillStyle='#888'; ctx.fillRect(tx+10,104,8,6); // Teller
    }
    // Speisekarte
    ctx.fillStyle='#1a1a1a'; ctx.fillRect(240,50,60,50);
    ctx.strokeStyle='#ff6644'; ctx.strokeRect(240,50,60,50);
    ctx.fillStyle='#ff6644'; ctx.font='5px monospace';
    ctx.fillText('MENÜ', 255, 60);
    ctx.fillText('Suppe: 2 DM', 245, 70);
    ctx.fillText('Nudeln: 3 DM', 245, 78);
    ctx.fillText('Kaffee: aus', 245, 86);
    // Fliesenboden
    ctx.fillStyle='#2a2a2a'; ctx.fillRect(0,SW.H-25,SW.W,25);
    for(let i=0;i<16;i++){ ctx.fillStyle=i%2?'#333':'#222'; ctx.fillRect(i*20,SW.H-25,20,25); }
  },

  artKapelle(ctx, room) {
    // Dunkles Holz
    ctx.fillStyle='#0a0a12'; ctx.fillRect(0,30,SW.W,SW.H-55);
    // Kreuz aus Schraubenziehern
    ctx.strokeStyle='#666'; ctx.lineWidth=3;
    ctx.beginPath(); ctx.moveTo(160,50); ctx.lineTo(160,100); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(145,65); ctx.lineTo(175,65); ctx.stroke();
    ctx.lineWidth=1;
    // Kerzen
    for(let i=0;i<5;i++){ const cx=80+i*40;
      ctx.fillStyle='#ccc'; ctx.fillRect(cx,110,4,15);
      ctx.fillStyle='#ffcc00';
      const flick=Math.floor(this._frame/8+i)%2===0;
      if(flick) ctx.fillRect(cx+1,106,2,4);
    }
    // Trauerband
    ctx.fillStyle='#333'; ctx.fillRect(0,130,SW.W,8);
    ctx.fillStyle='#888'; ctx.font='5px monospace'; ctx.textAlign='center';
    ctx.fillText('IN STILLER TRAUER', SW.CX, 136); ctx.textAlign='left';
    // Boden
    ctx.fillStyle='#0a0a0a'; ctx.fillRect(0,SW.H-25,SW.W,25);
  },

  artReparatur(ctx, room) {
    // Öl + Kabelsalat
    ctx.fillStyle='#1a1a12'; ctx.fillRect(0,30,SW.W,SW.H-55);
    // Warnleuchten
    for(let i=0;i<4;i++){ const blink=Math.floor(this._frame/15+i)%2===0;
      ctx.fillStyle=blink?'#ffcc00':'#332200'; ctx.fillRect(30+i*70,40,8,8); }
    // Kabel
    ctx.strokeStyle='#444'; ctx.lineWidth=2;
    for(let i=0;i<5;i++){ ctx.beginPath(); ctx.moveTo(20,60+i*15);
      ctx.quadraticCurveTo(160,50+i*20,300,60+i*15); ctx.stroke(); }
    ctx.lineWidth=1;
    // Werkzeugwand
    ctx.fillStyle='#2a2a2a'; ctx.fillRect(20,100,120,40);
    ctx.fillStyle='#888';
    for(let i=0;i<6;i++) ctx.fillRect(28+i*18,108,4,20);
    // Ölflüssigkeit
    ctx.fillStyle='#111'; ctx.fillRect(0,SW.H-30,SW.W,30);
    ctx.fillStyle='#222'; ctx.fillRect(50,SW.H-28,30,4); ctx.fillRect(200,SW.H-26,40,4);
  },

  artFriseur(ctx, room) {
    // Spiegelwände
    for(let i=0;i<3;i++){ const sx=30+i*90;
      ctx.fillStyle='#1a1a2a'; ctx.fillRect(sx,40,70,70);
      ctx.strokeStyle=room.akzent; ctx.strokeRect(sx,40,70,70);
      ctx.fillStyle='#333'; ctx.fillRect(sx+10,50,50,40); // Spiegel
      ctx.fillStyle=room.akzent; ctx.globalAlpha=0.3;
      ctx.fillRect(sx+15,55,10,30); ctx.globalAlpha=1;
    }
    // Stühle
    for(let i=0;i<3;i++){ const sx=50+i*90;
      ctx.fillStyle='#4a2a4a'; ctx.fillRect(sx,120,30,15);
      ctx.fillStyle='#333'; ctx.fillRect(sx+12,135,6,10);
    }
    // Bunte Tücher
    ctx.fillStyle=room.akzent; ctx.fillRect(0,30,SW.W,4);
    ctx.fillStyle='#ff66cc'; ctx.fillRect(0,34,SW.W,2);
    // Boden
    ctx.fillStyle='#2a1a2a'; ctx.fillRect(0,SW.H-25,SW.W,25);
  },

  artBeobachtung(ctx, room) {
    // Scheibewand ins Nichts — ändert sich je nach System
    const sys = SW.World.systemInfo();
    ctx.fillStyle='#020208'; ctx.fillRect(20,35,280,110);
    ctx.strokeStyle=sys.farbe; ctx.lineWidth=2; ctx.strokeRect(20,35,280,110);
    // Sterne
    ctx.fillStyle='#fff';
    for(let i=0;i<40;i++) ctx.fillRect(25+(i*17)%270, 40+(i*23)%100, 1,1);
    // Planet (System-Farbe)
    ctx.fillStyle=sys.farbe; ctx.globalAlpha=0.5;
    ctx.beginPath(); ctx.arc(240,70,18,0,Math.PI*2); ctx.fill();
    ctx.globalAlpha=1;
    // System-Label
    ctx.fillStyle=sys.farbe; ctx.font='bold 7px monospace'; ctx.textAlign='center';
    ctx.fillText(sys.name, 110, 55);
    ctx.fillStyle='#888'; ctx.font='5px monospace';
    ctx.fillText(sys.char.substring(0,38), 110, 65);
    ctx.textAlign='left';
    // Automata
    ctx.fillStyle='#333'; ctx.fillRect(250,120,40,25);
    ctx.fillStyle='#0f0'; ctx.fillRect(255,125,15,8);
    ctx.fillStyle='#000'; ctx.font='5px monospace'; ctx.fillText('50 PF', 272, 132);
    // Boden
    ctx.fillStyle='#0a0a1a'; ctx.fillRect(0,SW.H-25,SW.W,25);
  },

  artMaschinenraum(ctx, room) {
    // Rohre
    ctx.fillStyle='#1a1a22'; ctx.fillRect(0,30,SW.W,SW.H-55);
    for(let i=0;i<5;i++){ ctx.fillStyle='#333'; ctx.fillRect(20+i*60,40,15,90);
      ctx.fillStyle='#444'; ctx.fillRect(20+i*60,40,15,5); }
    // Hebel
    for(let i=0;i<4;i++){ ctx.fillStyle='#555'; ctx.fillRect(40+i*60,130,6,15);
      ctx.fillStyle='#f00'; ctx.fillRect(38+i*60,128,10,4); }
    // Brummende Motoren
    const pulse=Math.floor(this._frame/10)%2===0;
    ctx.fillStyle=pulse?'#0f0':'#030'; ctx.fillRect(20,150,280,8);
    // Boden
    ctx.fillStyle='#1a1a1a'; ctx.fillRect(0,SW.H-25,SW.W,25);
  },

  artKrankenstation(ctx, room) {
    // Steriles Weiß + grüne Akzente
    ctx.fillStyle='#1a2a2a'; ctx.fillRect(0,30,SW.W,SW.H-55);
    // Bettreihen
    for(let i=0;i<3;i++){ const bx=30+i*90;
      ctx.fillStyle='#ccc'; ctx.fillRect(bx,100,70,25);
      ctx.fillStyle='#00ccaa'; ctx.fillRect(bx,100,70,4);
      ctx.fillStyle='#fff'; ctx.fillRect(bx+5,105,20,15); // Kissen
    }
    // Herzmonitor
    ctx.fillStyle='#0a0a0a'; ctx.fillRect(240,45,60,35);
    ctx.strokeStyle='#00ccaa'; ctx.strokeRect(240,45,60,35);
    ctx.strokeStyle='#0f0'; ctx.beginPath();
    for(let i=0;i<40;i++){ const x=245+i; const y=62+((i/4)%2===0?-5:5);
      if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y); }
    ctx.stroke();
    // Tamagotchi
    ctx.fillStyle='#ffcc00'; ctx.fillRect(255,85,12,10);
    ctx.fillStyle='#000'; ctx.fillRect(258,88,2,2); ctx.fillRect(262,88,2,2);
    // Boden
    ctx.fillStyle='#2a3a3a'; ctx.fillRect(0,SW.H-25,SW.W,25);
  },

  artKlo(ctx, room) {
    // Kacheln (grau-grün)
    ctx.fillStyle='#1a2a2a'; ctx.fillRect(0,30,SW.W,SW.H-55);
    for(let i=0;i<16;i++){ ctx.fillStyle=i%2?'#2a3a3a':'#1a2a2a'; ctx.fillRect(i*20,SW.H-25,20,25); }
    // Spülung (links)
    ctx.fillStyle='#3a4a4a'; ctx.fillRect(30,80,40,50);
    ctx.fillStyle='#2a3a3a'; ctx.fillRect(35,85,30,30);
    ctx.fillStyle='#88ccaa'; ctx.fillRect(40,90,20,20); // Wasser
    // Spülknopf
    ctx.fillStyle='#666'; ctx.fillRect(45,70,10,8);
    // Wischmopp (rechts)
    ctx.fillStyle='#886644'; ctx.fillRect(250,60,4,60); // Stiel
    ctx.fillStyle='#ccaa88'; ctx.fillRect(245,115,14,15); // Moppkopf
    // Toner-Fleck (Witz)
    ctx.fillStyle='#111'; ctx.fillRect(150,130,20,8);
    ctx.fillStyle='#444'; ctx.font='5px monospace'; ctx.fillText('TONER', 152, 137);
    // Boden
    ctx.fillStyle='#1a2a2a'; ctx.fillRect(0,SW.H-25,SW.W,25);
    for(let i=0;i<16;i++){ ctx.fillStyle=i%2?'#2a3a3a':'#1a2a2a'; ctx.fillRect(i*20,SW.H-25,20,25); }
  },

  // ===== NPC RENDER =====
  renderNPCs(ctx, room) {
    const npcs = SW.World.npcInRoom(room.id);
    const positions = [[70,150],[160,155],[250,150]];
    for (let i=0; i<npcs.length && i<3; i++) {
      const name = npcs[i];
      const npcData = SW.RoomNPCs[name] || { farbe:'#888' };
      const x = positions[i][0], y = positions[i][1];
      // Silhouette
      ctx.fillStyle = npcData.farbe || '#888';
      ctx.globalAlpha = 0.7;
      ctx.fillRect(x-4, y-14, 8, 8); // Kopf
      ctx.fillRect(x-6, y-6, 12, 14); // Körper
      ctx.globalAlpha = 1;
      // Name
      ctx.fillStyle = '#ccc';
      ctx.font = '5px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(name, x, y+16);
      ctx.textAlign = 'left';
      // Klick-Region
      this._npcRects.push({ x: x-10, y: y-18, w: 20, h: 36, name: name });
    }
  },

  // ===== TÜR RENDER =====
  renderDoors(ctx, room) {
    const doors = room.toren;
    const destNames = doors.map(d => {
      const r = SW.Rooms.find(rr => rr.id === d);
      return r ? r.name : d;
    });
    // Türen auf den Wänden verteilen
    const layouts = {
      1: [[SW.CX-25, SW.H-38, 50, 20]],
      2: [[15, SW.H-38, 80, 20], [SW.W-95, SW.H-38, 80, 20]],
      3: [[15, 45, 20, 60], [SW.CX-25, SW.H-38, 50, 20], [SW.W-35, 45, 20, 60]],
      4: [[15, 45, 20, 60], [SW.CX-25, SW.H-38, 50, 20], [SW.W-35, 45, 20, 60], [SW.CX-25, 30, 50, 14]]
    };
    const pos = layouts[Math.min(doors.length, 4)] || layouts[3];
    for (let i=0; i<doors.length; i++) {
      const [dx, dy, dw, dh] = pos[i];
      // Tür
      ctx.fillStyle = '#0a0a0a';
      ctx.fillRect(dx, dy, dw, dh);
      ctx.strokeStyle = room.akzent;
      ctx.lineWidth = 1;
      ctx.strokeRect(dx, dy, dw, dh);
      // Pfeil
      ctx.fillStyle = room.akzent;
      ctx.font = '6px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('→ ' + destNames[i], dx + dw/2, dy + dh/2 + 2);
      ctx.textAlign = 'left';
      // Klick-Region
      this._doorRects.push({ x: dx, y: dy, w: dw, h: dh, to: doors[i] });
    }
  },

  // ===== MINIMAP =====
  renderMap(ctx, room) {
    const mx = SW.W-58, my = 30, mw = 50, mh = 40;
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(mx, my, mw, mh);
    ctx.strokeStyle = room.akzent;
    ctx.lineWidth = 1;
    ctx.strokeRect(mx, my, mw, mh);
    // Räume als Punkte (5x2 Grid)
    const cols = 5, rows = 2;
    const cw = mw/cols, ch = mh/rows;
    for (let i=0; i<SW.Rooms.length; i++) {
      const r = SW.Rooms[i];
      const gx = mx + (i%cols)*cw + cw/2;
      const gy = my + Math.floor(i/cols)*ch + ch/2;
      const isCurrent = r.id === room.id;
      const isNeighbor = room.toren.indexOf(r.id) >= 0;
      ctx.fillStyle = isCurrent ? r.akzent : (isNeighbor ? '#666' : '#333');
      ctx.fillRect(gx-2, gy-2, 4, 4);
      if (isCurrent) {
        ctx.strokeStyle = r.akzent;
        ctx.strokeRect(gx-3, gy-3, 6, 6);
      }
    }
    // Label
    ctx.fillStyle = room.akzent;
    ctx.font = '5px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('KARTE', mx+mw/2, my+mh-2);
    ctx.textAlign = 'left';
    // Klick-Region (Wandkarte → Fullscreen)
    this._mapRect = { x: mx, y: my, w: mw, h: mh };
  },

  // ===== DIALOG BOX =====
  renderDialogue(ctx, room) {
    const line = this.dialogueLines[this.dialogueIndex];
    const displayText = this.typing ? line.text.substring(0, this.charIndex) : line.text;
    // Box höher (54px) für 3 Zeilen
    const boxY = SW.H-84, boxH = 54;
    ctx.fillStyle = 'rgba(0,0,0,0.92)';
    ctx.fillRect(15, boxY, SW.W-30, boxH);
    ctx.strokeStyle = room.akzent;
    ctx.lineWidth = 1;
    ctx.strokeRect(15, boxY, SW.W-30, boxH);
    // Gesicht (Dialog-Namen sind UPPERCASE, RoomNPCs-Keys camelCase → case-insensitive Fallback)
    let npcData = SW.RoomNPCs[line.npc];
    if (!npcData) {
      const key = Object.keys(SW.RoomNPCs).find(k => k.toUpperCase() === String(line.npc).toUpperCase());
      npcData = key ? SW.RoomNPCs[key] : { farbe:'#888' };
    }
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = npcData.farbe;
    ctx.fillRect(22, boxY+6, 14, 16);
    ctx.globalAlpha = 0.6;
    ctx.fillStyle = '#000';
    ctx.fillRect(25, boxY+11, 3, 2);
    ctx.fillRect(31, boxY+11, 3, 2);
    ctx.fillRect(26, boxY+17, 6, 1);
    ctx.restore();
    // Name
    ctx.fillStyle = room.akzent;
    ctx.font = 'bold 7px monospace';
    ctx.fillText(line.npc, 42, boxY+12);
    // Text (3 Zeilen, Font 6px, Umbruch 44)
    ctx.fillStyle = '#0f0';
    ctx.font = '6px monospace';
    const words = displayText.split(' ');
    let l=''; const lines=[];
    for (const w of words) { if((l+w).length>44){lines.push(l);l=w+' ';}else{l+=w+' ';} }
    lines.push(l);
    for (let i=0;i<Math.min(lines.length,3);i++) ctx.fillText(lines[i].trim(), 42, boxY+24+i*8);
    if (!this.typing) {
      const blink = Math.floor(this._frame/30)%2===0;
      ctx.fillStyle = blink?'#fff':'#666';
      ctx.font = '6px monospace';
      ctx.textAlign='right';
      ctx.fillText('[LEER: weiter]', SW.W-22, boxY+boxH-4);
      ctx.textAlign='left';
    }
  },

  // ===== HINT (kein Dialog) =====
  renderHint(ctx, room) {
    const blink = Math.floor(this._frame/30)%2===0;
    ctx.fillStyle = blink?'#fff':'#666';
    ctx.font = '7px monospace';
    ctx.textAlign = 'center';
    if (room.id === 'flugdeck') {
      ctx.fillText('[ ZUR BRIEFING-TAFEL ]', SW.CX, SW.H-12);
    } else {
      ctx.fillText('[ Klicke auf NPCs oder Türen ]', SW.CX, SW.H-12);
    }
    ctx.textAlign = 'left';
  },

  // ===== CHEAT MAP (Fullscreen, Testing) =====
  _cheatMapRects: [],

  renderCheatMap(ctx) {
    ctx.fillStyle = '#020208';
    ctx.fillRect(0, 0, SW.W, SW.H);

    // Titel
    ctx.fillStyle = '#f66';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('FAX-TRAGÖDIE — RAUMKARTE [CHEAT]', SW.CX, 14);
    ctx.textAlign = 'left';

    // Schiff-Umriss (grober Träger: längliches Oval mit "Flügeln")
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(30, 100);
    ctx.lineTo(60, 60);
    ctx.lineTo(260, 60);
    ctx.lineTo(290, 100);
    ctx.lineTo(290, 140);
    ctx.lineTo(260, 160);
    ctx.lineTo(60, 160);
    ctx.lineTo(30, 140);
    ctx.closePath();
    ctx.stroke();
    // Triebwerke (hinten)
    ctx.strokeStyle = '#222';
    ctx.beginPath(); ctx.moveTo(30, 100); ctx.lineTo(15, 90); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(30, 140); ctx.lineTo(15, 150); ctx.stroke();
    // Nase (vorn)
    ctx.beginPath(); ctx.moveTo(290, 100); ctx.lineTo(305, 110); ctx.lineTo(290, 140); ctx.stroke();

    // Räume als Boxen (2 Reihen × 5-6)
    this._cheatMapRects = [];
    const rooms = SW.Rooms;
    const cols = 4, rows = 3;
    const bw = 68, bh = 42, gap = 8;
    const startX = 25, startY = 35;
    for (let i = 0; i < rooms.length; i++) {
      const r = rooms[i];
      const col = i % cols, row = Math.floor(i / cols);
      const x = startX + col * (bw + gap);
      const y = startY + row * (bh + gap);
      const isCurrent = r.id === this.currentRoom;
      // Box
      ctx.fillStyle = isCurrent ? 'rgba(0,255,0,0.15)' : 'rgba(0,0,0,0.6)';
      ctx.fillRect(x, y, bw, bh);
      ctx.strokeStyle = isCurrent ? r.akzent : '#444';
      ctx.lineWidth = isCurrent ? 2 : 1;
      ctx.strokeRect(x, y, bw, bh);
      // Raum-Name
      ctx.fillStyle = isCurrent ? r.akzent : '#aaa';
      ctx.font = 'bold 6px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(r.name, x + bw/2, y + 12);
      // Zweck (klein)
      ctx.fillStyle = '#666';
      ctx.font = '5px monospace';
      const zw = r.zweck.substring(0, 28);
      ctx.fillText(zw, x + bw/2, y + 22);
      // NPC-Count
      const npcs = SW.World.npcInRoom(r.id);
      ctx.fillStyle = '#0f0';
      ctx.font = '5px monospace';
      ctx.fillText(npcs.length + ' NPC', x + bw/2, y + 34);
      ctx.textAlign = 'left';
      // Klick-Region
      this._cheatMapRects.push({ x, y, w: bw, h: bh, room: r.id });
    }

    // Hinweis
    const blink = Math.floor(Date.now()/500)%2===0;
    ctx.fillStyle = blink ? '#fff' : '#666';
    ctx.font = '7px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('[ Klicke auf Raum = dorthin | ESC = zurück ]', SW.CX, SW.H-10);
    ctx.textAlign = 'left';
  },

  handleCheatMapClick(mx, my) {
    for (const r of this._cheatMapRects) {
      if (mx >= r.x && mx <= r.x + r.w && my >= r.y && my <= r.y + r.h) {
        this.currentRoom = r.room;
        this.dialogueActive = false;
        this.talkingNPC = null;
        SW.Game.setState('SHIP');
        return;
      }
    }
  }
};
